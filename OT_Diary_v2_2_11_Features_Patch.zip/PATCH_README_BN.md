# OT Diary 2.2.0 (+3) — ১১ ফিচারের Source Patch

Base: `ilovetajul/ot_diary_flutter`, `feature/modern-ot-diary`, commit `00eb7b708dbc48ca96efe9f5432bfd124d679013` (Run #20 সফল)। ১৩টি প্রতিস্থাপিত মূল ফাইলের Git blob SHA সরাসরি GitHub-এর সঙ্গে মিলিয়ে নেওয়া হয়েছে। ZIP-এ ১৩টি পরিবর্তিত ও ৬টি নতুন source/test/resource ফাইল আছে। কোনো ফাইল মুছে ফেলার নির্দেশ নেই।

## কী যোগ করা হয়েছে
হোমের “ক্যালেন্ডার • দ্রুত OT • আরও সুবিধা” থেকে ক্যালেন্ডার, ২/৩/৫/৭ ঘণ্টার Quick Entry (বিদ্যমান এন্ট্রি বদলালে নিশ্চিতকরণ), কাস্টম OT, ছুটির চিহ্ন, মাসিক লক্ষ্য, বাংলা PDF, Excel-compatible CSV, বার্ষিক OT রিপোর্ট, JSON backup, নিরাপদ restore, Light/Dark theme এবং Android home-screen widget পাওয়া যাবে। Login-এ password reset email যুক্ত হয়েছে। মূল PDF, OT breakdown, reminder, Firebase configuration, application ID ও সফল CI workflow রাখা হয়েছে।

## গুরুত্বপূর্ণ সীমাবদ্ধতা
- Full Flutter analyze/test/Android build এখানে চালানো হয়নি; Flutter SDK নেই। ৩টি নতুন test লেখা হয়েছে; ফলাফল CI-তে নিশ্চিত করতে হবে। XML parse ও git diff --check পাস করেছে; source blob matching হয়েছে।
- Calendar holiday ও monthly target একই ফোনে user/month অনুযায়ী সংরক্ষিত; cloud sync নেই। Theme পছন্দ ডিভাইসব্যাপী।
- CSV Excel-এ খোলে; native XLSX নয়। বাংলা PDF Flutter text engine দিয়ে render করা image-based (searchable/selectable text নয়)। Annual income বর্তমান OT rate দিয়ে আনুমানিক।
- Online backup-এ পাওয়া server data ও pending local operations, profile metadata, goals/holidays থাকে। Offline হলে কেবল পাওয়া local cache ও pending data; UI-তে partial বলা হয়। Backup server snapshot ও local queue-এর atomic transaction নয়। Profile photo binary, password ও auth token export করা হয় না। JSON-এ ব্যক্তিগত তথ্য থাকে, encrypt করা হয়নি।
- Restore শুধু একই Firebase UID-তে, online, pending data sync হওয়ার পরে; transaction দিয়ে অনুপস্থিত OT day যোগ করে, বিদ্যমান OT/profile overwrite করে না। লক্ষ্য ও ছুটির চিহ্ন merge করে। প্রোফাইল metadata informational, avatar বা পূর্ণ profile restore নয়। মাঝপথে connection fail হলে কিছু day restore হতে পারে; retry করলে existing day skip হবে। Production Firebase-এ প্রথমে পরীক্ষা নয়।
- Widget মাসের OT ঘণ্টা ও দিন দেখায়, অ্যাপের data load/save বা manual refresh-এ update হয়; background cloud sync widget নয়। Launcher widget support ও password reset mail Firebase configuration-এর ওপর নির্ভরশীল।
- পূর্বের সব Sync edge case সমাধান করা হয়নি। RTDB map/list decoding ও cache read-এ stale deleted day না ফেরানোর পরিবর্তন আছে; দুই ডিভাইসে conflict এবং offline reopen test জরুরি।

## Apply (মোবাইল GitHub Codespaces বা write-access ChatGPT)
1. সফল `feature/modern-ot-diary` ব্রাঞ্চের HEAD এই base commit কিনা যাচাই করুন। পরিবর্তন হয়ে থাকলে সরাসরি overwrite নয়; diff review করে merge করুন।
2. আলাদা `feature/ot-diary-v2.2` ব্রাঞ্চ তৈরি করুন। ZIP extract করে `lib/`, `android/`, `test/`, `pubspec.yaml`, `CHANGELOG.md` একই path-এ copy/replace করুন। ZIP নিজে শুধু upload করলে code update হবে না। `PATCH_README_BN.md` ও `FILES_SHA256.txt` চাইলে repository-তে না রাখলেও হবে।
3. বর্তমান `feature-ci.yml` workflow শুধু `feature/modern-ot-diary` push-এ auto-run করে। v2.2 branch-এর workflow_dispatch দিয়ে চালাতে হলে workflow GitHub default branch-এ available কিনা যাচাই করুন। নতুন branch-এ CI চালানোর জন্য সেই branch-এর `.github/workflows/feature-ci.yml`-এর `on.push.branches`-এ `feature/ot-diary-v2.2` যোগ করুন। **বাকি সফল SDK, Gradle, Maven Central, icon ও artifact setup বদলাবেন না।**
4. `flutter pub get` চালান; `dart format` শুধু পরিবর্তিত Dart files-এ চালান। `flutter analyze`-এ lint থাকলে সেগুলি ঠিক করুন (theme runtime conversion-এর পরে প্রয়োজনীয় const lint fixes করুন, compile errors না লুকিয়ে)। `flutter test`, `flutter build apk --debug` চালান। নতুন branch CI success ও APK artifact না হওয়া পর্যন্ত merge করবেন না।
5. নতুন APK test account / separate device-এ পরীক্ষা করুন। Existing installation uninstall/clear data করবেন না; package ID ও signing certificate match দরকার।

## Test checklist
- পুরোনো OT/profile/notification/photo intact; existing monthly English PDF ও breakdown কাজ করে।
- মাস পাল্টানো, leap year, Quick Entry, invalid numeric input, existing value confirmation।
- Offline entry → app close/reopen → reconnect → sync; দুই device-এ deletion।
- Light/Dark সব screen, relaunch persistence, contrast।
- Password reset email, invalid email/network error।
- JSON online ও offline partial; অন্য account backup reject; restore existing data unchanged; নতুন day আসে; retry নিরাপদ।
- Bangla PDF glyphs/যুক্তাক্ষর, CSV Excel-এ, annual totals; goal persisted, holiday marker persisted।
- Android launcher Widget add, entry save, month change, logout এবং app reopen।
- নতুন CI run-এর Analyze/Test/Build/Upload সফল ও APK artifact download।

## পরিবর্তিত ও নতুন ফাইল
- `CHANGELOG.md`
- `android/app/build.gradle`
- `android/app/src/main/AndroidManifest.xml`
- `android/app/src/main/kotlin/com/otdiary/app/MainActivity.kt`
- `android/app/src/main/kotlin/com/otdiary/app/OtSummaryWidget.kt`
- `android/app/src/main/res/layout/ot_summary_widget.xml`
- `android/app/src/main/res/xml/ot_summary_widget_info.xml`
- `lib/app_theme.dart`
- `lib/main.dart`
- `lib/screens/auth_screen.dart`
- `lib/screens/chart_screen.dart`
- `lib/screens/extra_tools_screen.dart`
- `lib/screens/home_screen.dart`
- `lib/screens/settings_screen.dart`
- `lib/screens/splash_screen.dart`
- `lib/services/database_service.dart`
- `lib/services/extra_tools.dart`
- `pubspec.yaml`
- `test/extra_tools_test.dart`
