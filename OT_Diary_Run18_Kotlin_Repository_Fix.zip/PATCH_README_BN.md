# OT Diary — Run #18 Kotlin dependency resolution fix

## Run #18-এর যাচাইকৃত ফলাফল

এই Run-এ নিচের ধাপগুলো সফল হয়েছে:
- Android SDK setup
- Launcher icon generation ও verification
- `flutter analyze`
- `flutter test` (৩টি test passed)

শুধু `flutter build apk --debug` ব্যর্থ হয়েছে।

## আসল Error

Gradle Flutter-এর included build (`$FLUTTER_ROOT/packages/flutter_tools/gradle`) configure করার সময় Kotlin DSL dependency resolve করতে পারেনি:

- `org.jetbrains.kotlin:kotlin-stdlib:2.2.21`
- `org.jetbrains.kotlin:kotlin-gradle-plugin:2.2.21`
- `org.jetbrains.kotlin:kotlin-gradle-plugins-bom:2.2.21`
- `org.jetbrains.kotlin:kotlin-gradle-plugin-api:2.2.21`

Log-এ dependency search শুধু `https://plugins.gradle.org/m2/`-এ হয়েছে। Kotlin 2.2.21 artifact Maven Central-এ প্রকাশিত আছে; তাই এই included build-এর pluginManagement repositories-এ Maven Central যোগ করা দরকার।

## এই Patch কী করে

শুধু `.github/workflows/feature-ci.yml` পরিবর্তন করে।

Flutter SDK setup হওয়ার পর CI runner-এর অস্থায়ী Flutter SDK ফাইলে:
`$FLUTTER_ROOT/packages/flutter_tools/gradle/settings.gradle.kts`

নিচের pluginManagement block শুরুতে যোগ করে (যদি আগে না থাকে):

```kotlin
pluginManagement {
    repositories {
        mavenCentral()
        google()
        gradlePluginPortal()
    }
}
```

এটি Repository-র Android source/config file পরিবর্তন করে না; শুধু GitHub Actions runner-এর ephemeral Flutter SDK configure করে, যাতে included Flutter Gradle build Kotlin plugin marker এবং transitive Kotlin artifacts সঠিক repository থেকে resolve করতে পারে।

## Apply করার নিয়ম

1. ZIP Extract করুন।
2. Repository `ilovetajul/ot_diary_flutter` খুলুন।
3. শুধু `feature/modern-ot-diary` branch-এ যান।
4. `.github/workflows/feature-ci.yml`-কে ZIP-এর একই path-এর ফাইল দিয়ে সম্পূর্ণ replace করুন।
5. Commit ও Push করুন।
6. নতুন Actions Run-এ `Add Maven Central to Flutter Gradle plugin repositories` step সফল হয়েছে কি না দেখুন।
7. তারপর `Build debug APK` এবং `Upload Debug APK` সফল হয়েছে কি না দেখুন।

Commit message:
`Fix Maven Central resolution for Flutter included Gradle build`

## Data safety

এই Patch:
- Firebase Realtime Database path পরিবর্তন করে না
- Firebase Authentication/Storage configuration পরিবর্তন করে না
- User profile বা OT data পরিবর্তন করে না
- Application ID পরিবর্তন করে না
- `main` branch পরিবর্তন করে না
- শুধু CI workflow file পরিবর্তন করে

## APK Download

Build এবং Upload দুই ধাপই সফল হলে GitHub Actions run page-এর Artifacts অংশে `OT-Diary-feature-debug-apk` দেখা যাবে। ZIP artifact-এর ভেতরে `app-debug.apk` থাকবে।

Patch upload করা বা workflow commit হওয়া মানেই build সফল—এমন নয়। নতুন Actions Run সফল হলে তবেই APK download করা যাবে।
