# OT Diary — Android Gradle compatibility patch

## সর্বশেষ Actions Run #10-এর ফলাফল
- `flutter pub get`: সফল
- `flutter analyze`: সফল
- `flutter test`: সফল
- `Build debug APK`: ব্যর্থ

মূল Error: Flutter 3.50.1-এর জন্য AGP কমপক্ষে 9.1.1 প্রয়োজন, কিন্তু Branch-এ 8.5.2 ছিল। Gradle Wrapper ইতোমধ্যে 9.3.1 এবং CI Java 17 ব্যবহার করছে।

## এই Patch-এ পরিবর্তন
1. `android/settings.gradle`
   - AGP `8.5.2` → `9.1.1`
   - Kotlin Gradle Plugin `1.9.22` → `2.2.10`
2. `android/gradle.properties`
   - `android.builtInKotlin=false`
   - `android.newDsl=false`

এটি Flutter-এর documented temporary compatibility mode, যাতে AGP 9.x-এর সঙ্গে বর্তমান legacy Kotlin Gradle Plugin ও পুরোনো AGP DSL ব্যবহার চালু রাখা যায়।

## Apply করার নিয়ম
**শুধু `feature/modern-ot-diary` Branch-এ Apply করবেন; `main` Branch-এ নয়।**

1. এই ZIP-এর `android/settings.gradle` দিয়ে Repository-এর একই ফাইল সম্পূর্ণ Replace করুন।
2. এই ZIP-এর `android/gradle.properties` দিয়ে Repository-এর একই ফাইল সম্পূর্ণ Replace করুন।
3. `android/gradle/wrapper/gradle-wrapper.properties`-এ `gradle-9.3.1-bin.zip` আছে কি না যাচাই করুন। এই Patch সেটি পরিবর্তন করে না।
4. Commit message: `Fix AGP 9.1.1 and Kotlin compatibility for Flutter 3.50.1`
5. Push করার পর নতুন GitHub Actions Run-এর ফলাফল পরীক্ষা করুন।

## Verification checklist
- [ ] `flutter pub get`
- [ ] `flutter analyze`
- [ ] `flutter test`
- [ ] `flutter build apk --debug`
- [ ] APK artifact তৈরি
- [ ] Android ডিভাইসে app launch
- [ ] Firebase login এবং পুরোনো OT data read/write
- [ ] Offline entry ও reconnect sync

## Data safety
এই Patch Firebase Database path, Authentication, Storage path, applicationId, পুরোনো OT data বা database migration পরিবর্তন করে না। শুধু Android build configuration বদলায়।

**সতর্কতা:** Patch তৈরি হয়েছে, কিন্তু নতুন Actions Run সফল না হওয়া পর্যন্ত Build ঠিক হয়েছে বলা যাবে না।
