# OT Diary CI Fix — বাংলা নির্দেশিকা

## সর্বশেষ Run #16-এর আসল Error

GitHub Actions-এর Run #16 (`eb57ed7`) `Setup Android SDK` ধাপেই ব্যর্থ হয়েছে।

লগে দেখা যায়:
- `android-actions/setup-android@v3`-এর default package list `tools platform-tools`
- action `sdkmanager tools` চালায়
- SDK Manager জানায়: `Failed to find package 'tools'`

`tools` হলো পুরোনো/অবসরে যাওয়া SDK package। তাই আগেরবার `Setup Android SDK` action যুক্ত করার পরও সেটি ব্যর্থ হয়েছে।

## এই Patch কী বদলায়

শুধু `.github/workflows/feature-ci.yml` ফাইল।

গুরুত্বপূর্ণ পরিবর্তন:
```yaml
- name: Setup Android SDK
  uses: android-actions/setup-android@v3
  with:
    packages: ''
```

এরপর পরের ধাপে প্রয়োজনীয় package স্পষ্টভাবে ইনস্টল হয়:
- `platform-tools`
- `platforms;android-36`
- `ndk;28.2.13676358`

তারপর:
1. `flutter clean`
2. `flutter pub get`
3. `dart run flutter_launcher_icons`
4. Icon ফাইল তৈরি হয়েছে কি না যাচাই
5. `flutter analyze`
6. `flutter test`
7. `flutter build apk --debug`
8. `actions/upload-artifact@v4` দিয়ে APK Upload

## Apply করার নিয়ম

1. Repository: `ilovetajul/ot_diary_flutter`
2. Branch: `feature/modern-ot-diary`
3. ZIP Extract করুন।
4. Extract করা `.github/workflows/feature-ci.yml` দিয়ে Branch-এর একই ফাইল সম্পূর্ণ Replace করুন।
5. শুধু এই Branch-এ Commit ও Push করুন।
6. নতুন GitHub Actions Run সম্পন্ন হওয়া পর্যন্ত অপেক্ষা করুন।

Commit message:
`Fix obsolete Android SDK tools package in CI`

## Data safety

এই Patch শুধু GitHub Actions workflow পরিবর্তন করে। Firebase config, Realtime Database path, Authentication, Storage, applicationId, OT records বা app source code পরিবর্তন করে না। `main` Branch পরিবর্তন করা হয়নি।

## APK Download কখন আসবে?

শুধু Build সফল হলে এবং `Upload Debug APK` ধাপ সফল হলে Actions Run-এর Artifacts অংশে `OT-Diary-feature-debug-apk` দেখা যাবে। এর ভেতরে `app-debug.apk` থাকবে।

এই Patch তৈরি হওয়া মানে Build সফল হয়েছে—এমন নয়। Push করার পর নতুন Run-এর ফলাফল যাচাই করতে হবে।
